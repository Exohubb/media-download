document.getElementById('download-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const url = document.getElementById('url').value;
    const format = document.getElementById('format').value;
    const messageDiv = document.getElementById('message');
    
    messageDiv.textContent = 'Processing...';
    
    fetch('/download', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ url: url, format: format })
    })
    .then(response => {
      if (!response.ok) {
        return response.json().then(data => { throw new Error(data.error || 'Error during download'); });
      }
      return response.blob();
    })
    .then(blob => {
      const downloadUrl = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = downloadUrl;
      a.download = `downloaded_file.${format}`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(downloadUrl);
      messageDiv.textContent = 'Download complete.';
    })
    .catch(err => {
      console.error(err);
      messageDiv.textContent = 'Error: ' + err.message;
    });
  });
  